
import pandas as pd


def clean_stock_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Clean and validate historical stock data.
    """

    df = df.copy()

    # Remove duplicate dates
    df = df.drop_duplicates(subset=["date"])

    # Sort data chronologically
    df = df.sort_values("date").reset_index(drop=True)

    # Handle missing values
    df = df.dropna(
        subset=["date", "open", "high", "low", "close", "volume"]
    )

    # Validate OHLC prices
    price_columns = ["open", "high", "low", "close"]

    for column in price_columns:
        df = df[df[column] > 0]

    # Volume cannot be negative
    df = df[df["volume"] >= 0]

    # Validate high and low
    df = df[
        (df["high"] >= df["low"])
        & (df["high"] >= df["open"])
        & (df["high"] >= df["close"])
        & (df["low"] <= df["open"])
        & (df["low"] <= df["close"])
    ]

    return df.reset_index(drop=True)
