
import pandas as pd
from sqlalchemy.orm import Session

from app.models.stock import Stock
from app.models.stock_price import StockPrice


def load_stock_data(db: Session, symbol: str) -> pd.DataFrame:
    """
    Load historical stock prices from PostgreSQL.
    """

    records = (
        db.query(
            Stock.symbol,
            StockPrice.date,
            StockPrice.open,
            StockPrice.high,
            StockPrice.low,
            StockPrice.close,
            StockPrice.volume,
        )
        .join(StockPrice, Stock.id == StockPrice.stock_id)
        .filter(Stock.symbol == symbol.upper())
        .order_by(StockPrice.date.asc())
        .all()
    )

    if not records:
        raise ValueError(f"No historical data found for {symbol}")

    df = pd.DataFrame(
        records,
        columns=[
            "symbol",
            "date",
            "open",
            "high",
            "low",
            "close",
            "volume",
        ],
    )

    df["date"] = pd.to_datetime(df["date"], utc=True)

    return df
