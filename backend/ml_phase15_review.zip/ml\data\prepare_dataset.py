
from typing import Tuple

import pandas as pd



FEATURE_COLUMNS = [
    # Returns and volatility
    "return_1d",
    "return_5d",
    "volatility_5",
    "volume_change",

    # Relative price features
    "open_ratio",
    "high_ratio",
    "low_ratio",
    "sma5_ratio",
    "sma10_ratio",
    "ema20_ratio",

    # Technical indicators
    "rsi_14",
    "macd",
    "macd_histogram",
    "momentum_10",
    "bb_position",
]



def prepare_train_test_data(
    df: pd.DataFrame,
    test_size: float = 0.2
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:

    df = df.sort_values("date").reset_index(drop=True)

    X = df[FEATURE_COLUMNS]
    y = df["target"]

    split_index = int(len(df) * (1 - test_size))

    X_train = X.iloc[:split_index]
    X_test = X.iloc[split_index:]

    y_train = y.iloc[:split_index]
    y_test = y.iloc[split_index:]

    return X_train, X_test, y_train, y_test
