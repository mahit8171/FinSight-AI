
import pandas as pd

from app.db.database import SessionLocal
from app.models.stock import Stock

from app.ml.data.load_data import load_stock_data
from app.ml.data.clean_data import clean_stock_data
from app.ml.features.build_features import build_features
from app.ml.data.prepare_dataset import FEATURE_COLUMNS


def prepare_multi_stock_dataset():

    db = SessionLocal()

    try:
        stocks = db.query(Stock.symbol).order_by(Stock.symbol).all()

        datasets = []

        for (symbol,) in stocks:

            df = load_stock_data(db, symbol)
            df = clean_stock_data(df)
            df = build_features(df)

            # Target and target_date are already created
            # together inside build_features.py.
            df["target_return"] = (
                df["target"] / df["close"]
            ) - 1

            df = df.dropna(
                subset=FEATURE_COLUMNS + ["target_return"]
            )

            datasets.append(df)

            print(f"{symbol}: {len(df)} rows")

        combined_df = (
            pd.concat(datasets, ignore_index=True)
            .sort_values(["date", "symbol"])
            .reset_index(drop=True)
        )

        print("\nCombined dataset shape:", combined_df.shape)
        print("Unique stocks:", combined_df["symbol"].nunique())

        return combined_df

    finally:
        db.close()


if __name__ == "__main__":
    prepare_multi_stock_dataset()
