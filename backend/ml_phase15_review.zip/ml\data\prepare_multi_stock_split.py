
from app.ml.data.prepare_multi_stock_dataset import (
    prepare_multi_stock_dataset
)
from app.ml.data.prepare_dataset import FEATURE_COLUMNS


def prepare_multi_stock_split(test_size: float = 0.2):

    df = prepare_multi_stock_dataset()

    train_parts = []
    test_parts = []

    for symbol, stock_df in df.groupby("symbol"):

        stock_df = stock_df.sort_values("date").reset_index(drop=True)

        split_index = int(len(stock_df) * (1 - test_size))

        train_parts.append(stock_df.iloc[:split_index])
        test_parts.append(stock_df.iloc[split_index:])

    train_df = (
        __import__("pandas").concat(train_parts)
        .sort_values(["date", "symbol"])
        .reset_index(drop=True)
    )

    test_df = (
        __import__("pandas").concat(test_parts)
        .sort_values(["date", "symbol"])
        .reset_index(drop=True)
    )

    X_train = train_df[FEATURE_COLUMNS + ["symbol"]]

    y_train = train_df["target_return"]

    X_test = test_df[FEATURE_COLUMNS + ["symbol"]]
    y_test = test_df["target_return"]

    print("\nMulti-stock split results")
    print("Training rows:", len(X_train))
    print("Testing rows:", len(X_test))
    print("Training stocks:", train_df["symbol"].nunique())
    print("Testing stocks:", test_df["symbol"].nunique())

    return X_train, X_test, y_train, y_test


if __name__ == "__main__":
    prepare_multi_stock_split()
