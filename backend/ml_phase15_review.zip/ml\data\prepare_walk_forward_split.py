
import pandas as pd

from app.ml.data.prepare_multi_stock_dataset import prepare_multi_stock_dataset
from app.ml.data.prepare_dataset import FEATURE_COLUMNS


def prepare_walk_forward_split(
    test_size: float = 0.2,
    n_splits: int = 3,
):
    df = prepare_multi_stock_dataset()

    unique_dates = sorted(df["date"].unique())

    total_dates = len(unique_dates)
    initial_train_size = int(total_dates * 0.4)
    test_period_size = int(
        (total_dates - initial_train_size) / n_splits
    )

    if test_period_size == 0:
        raise ValueError("Not enough dates for walk-forward validation")

    folds = []

    for fold in range(n_splits):
        train_end = initial_train_size + fold * test_period_size
        test_end = (
            train_end + test_period_size
            if fold < n_splits - 1
            else total_dates
        )

        train_dates = unique_dates[:train_end]
        test_dates = unique_dates[train_end:test_end]

        train_df = df[df["date"].isin(train_dates)].copy()
        test_df = df[df["date"].isin(test_dates)].copy()

        # Remove training rows whose target falls in the test period
        test_start_date = test_df["date"].min()

        train_df = train_df[
            train_df["target_date"] < test_start_date
        ].copy()
        print(
            "Latest training target date:",
            train_df["target_date"].max()
        )

        print(
            "Earliest testing date:",
            test_df["date"].min()
        )

        print(
            "Leakage check:",
            train_df["target_date"].max() < test_df["date"].min()
        )
        X_train = train_df[FEATURE_COLUMNS + ["symbol"]]
        X_test = test_df[FEATURE_COLUMNS + ["symbol"]]

        y_train = train_df["target_return"]
        y_test = test_df["target_return"]

        folds.append((X_train, X_test, y_train, y_test))

        print(f"\nFold {fold + 1}")
        print("Training dates:", len(train_dates))
        print("Testing dates:", len(test_dates))
        print("Training rows:", len(train_df))
        print("Testing rows:", len(test_df))
        print("Train date range:", train_df["date"].min(), "to", train_df["date"].max())
        print("Test date range:", test_df["date"].min(), "to", test_df["date"].max())

    return folds


if __name__ == "__main__":
    prepare_walk_forward_split()
