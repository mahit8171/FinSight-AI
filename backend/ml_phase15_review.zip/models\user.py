from sqlalchemy import Column, Integer, String, Boolean, DateTime, func
from sqlalchemy.orm import Mapped , mapped_column
from sqlalchemy.sql import func

from app.db.database import Base

class User(Base):
    __tablename__ = "users"
    id:Mapped[int] = mapped_column(primary_key=True , index=True)
    
    name:Mapped[str] = mapped_column(String(100) , nullable=False)
    
    email:Mapped[str] = mapped_column(String(255) , unique=True , index= True , nullable=False)
    
    hashed_password:Mapped[str] = mapped_column(String(255) , nullable=False)
    
    is_active:Mapped[bool] = mapped_column(Boolean , default=True)
    
    created_at:Mapped[DateTime] = mapped_column(
        DateTime(timezone=True) , 
        server_default=func.now()
    )
    
    role = Column(
    String(20),
    nullable=False,
    default="user",
    server_default="user"
    )